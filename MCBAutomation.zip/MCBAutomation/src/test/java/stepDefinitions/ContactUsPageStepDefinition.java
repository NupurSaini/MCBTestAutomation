package stepDefinitions;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

import com.MCBAutomation.pages.ContactUsPage;
import com.MCBAutomation.util.BaseClass;
import com.MCBAutomation.util.BaseUtil;

import cucumber.api.java.After;
import cucumber.api.java.Before;
import cucumber.api.java.en.*;

public class ContactUsPageStepDefinition extends BaseClass {

	ContactUsPage contactUsPage;
	Select select;

	@Before
	public void open_web_application() {
		BaseClass.initialization();
		contactUsPage = new ContactUsPage();
	}

	@After
	public void close_web_application() {
		driver.quit();
	}

	@Given("^You are are on a contact us page$")
	public void you_are_are_on_a_contact_us_page() {
		contactUsPage.correctPageLoaded();
	}

	@Then("^Verify the URL of contact us page$")
	public void verify_the_URL_of_contact_us_page() {
		contactUsPage.verifyCurrentURL();
	}

	@Then("^Verify contact Us page loaded successfully$")
	public void verify_contact_us_page_loaded_successfully() {
		boolean flag = contactUsPage.elementContactUsVisible();
		Assert.assertTrue(flag);
	}

	@When("^Scroll down page to \"(.*)\" pixel$")
	public void scroll_down_page_to_pixel(int arg1) {
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("window.scrollBy(0," + arg1 + ")");
	}

	@Then("^Check the visibility of feedback field$")
	public void check_the_visibility_of_feedback_field()  {
		boolean flag = contactUsPage.elementFeedbackVisible();
		Assert.assertTrue(flag);
	}

	@Then("^Verify the default value is in feedback box$")
	public void verify_the_default_value_is_in_feedback_box()  {
		select = new Select(driver.findElement(By.xpath("//select[1]")));
		WebElement option = select.getFirstSelectedOption();
		String defaultItem = option.getText();
		Assert.assertTrue(defaultItem.equals(BaseUtil.defaultTextOfFeedbackBox));
	}
	
	@Then("^Click on feedback Box$")
	public void click_on_feedback_box() {
		contactUsPage.clickFeedbackBox();
	}

	@Then("^Verify all of the options are correct in dropdown of feedback box$")
	public void verify_all_of_the_options_are_correct_in_dropdown_of_feedback_box() {
		select = new Select(driver.findElement(By.xpath("//select[1]")));
		java.util.List<WebElement> options = select.getOptions();
		int k = 0;
		for (WebElement opt : options) {
			Assert.assertTrue(opt.getText().equals(BaseUtil.expectedFeedbackValue[k]));
			k = k + 1;
		}
	}

}
