package com.MCBAutomation.pages;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.MCBAutomation.util.BaseClass;
import com.MCBAutomation.util.BaseUtil;
import com.MCBAutomation.webElements.contactUsPageWebElements;

/**
 * This page contains state and the behaviour of contact information test case
 * 
 * @author jitenderkumar01
 *
 */
public class ContactUsPage extends BaseClass {

	
	public static String contactUs = "//*[@id=\"main-content\"]/div/div[1]/div/div/div/h1";
	 public static String feedback = "//*[@id=\"formName\"]/div/div[2]/div/div[1]/label/span";
	 public static String feedbackBox = "//select[1]";
	
	 
	public ContactUsPage() {
		driver = this.driver;
	}

	public void correctPageLoaded() {
		WebDriverWait wait = new WebDriverWait(driver, 60);
		boolean flag = wait.until(ExpectedConditions.titleContains(BaseUtil.contactUsPageTitle));
		Assert.assertTrue(flag);
	}

	public void verifyCurrentURL() {
		boolean flag = driver.getCurrentUrl().equalsIgnoreCase(BaseUtil.contactUsPageURL);
		Assert.assertTrue(flag);
	}

	public boolean elementContactUsVisible() {
		 WebElement e = driver.findElement(By.xpath(contactUs));
		return e.isDisplayed();
	}

	public void clickFeedbackBox() {
		driver.findElement(By.xpath(feedbackBox)).click();
	}
	
	public boolean elementFeedbackVisible() {
		 WebElement e = driver.findElement(By.xpath(feedback));
		return e.isDisplayed();
	}
}
