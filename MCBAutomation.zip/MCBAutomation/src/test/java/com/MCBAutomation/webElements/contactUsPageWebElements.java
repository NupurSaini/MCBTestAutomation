package com.MCBAutomation.webElements;

public class contactUsPageWebElements {

	
	public static String contactUs = "//*[@id=\"main-content\"]/div/div[1]/div/div/div/h1";
	 public static String feedback = "//*[@id=\"formName\"]/div/div[2]/div/div[1]/label/span";
	 public static String feedbackBox = "//select[1]";
	
	 
}
