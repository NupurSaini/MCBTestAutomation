package com.MCBAutomation.testRunner;

import org.junit.AfterClass;
import org.junit.runner.RunWith;

import com.MCBAutomation.util.BaseClass;
import com.cucumber.listener.Reporter;
import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;

@RunWith(Cucumber.class)
@CucumberOptions(features = "src/test/java/com/MCBAutomation/features", glue = {
		"stepDefinitions" }, monochrome = true, strict = true, dryRun = false, tags= {"@contactUsPageTest,@defaultValuesOfFeedback"},plugin = {
				"com.cucumber.listener.ExtentCucumberFormatter:target/cucumber-reports/report.html" })

public class TestRunner {
	@AfterClass
	public static void writeExtentReport() {
		Reporter.loadXMLConfig(BaseClass.getReportConfigPath());
	}
}
